SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";
--
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

-- Database: `renthouse`

CREATE TABLE `add_property` (
  `property_id` int(10) NOT NULL,
  `estimated_price` bigint(10) NOT NULL,
  `location` varchar(50) NOT NULL,
  `type` varchar(100) NOT NULL,
  `area` int(30) NOT NULL,
  `description_age` int(10) NOT NULL,
  `description_gender` varchar(2000) NOT NULL,
  `owner_id` int(10) NOT NULL,
  `booked` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `add_property` (`property_id`,`estimated_price`,`location`,`type`,`area`,`description_age`,`description_gender`,`owner_id`,`booked`) VALUES
('101','11000','Vijaynagar','2bhk','700','18','Male','1','NO'),
('102','12000','Kuvempunagar','2bhk','800','19','Female','1','NO'),
('103','9000','Vijaynagar','2bhk','650','20','Any','2','NO'),
('104','10000','VV Mohalla','2bhk','700','21','Male','2','NO'),
('105','7000','Bannimantap','1bhk','550','22','Female','3','NO'),
('106','8000','Gokulam','2bhk','650','18','Any','3','NO'),
('107','8500','JP nagar','2bhk','700','19','Male','4','NO'),
('108','9000','Bogadi','2bhk','750','20','Female','4','NO'),
('109','6500','Gokulam','1bhk','500','21','Any','5','NO'),
('110','14000','Kuvempunagar','3bhk','1000','22','Male','5','NO'),
('111','8500','Bannimantap','2bhk','700','18','Female','6','NO'),
('112','7500','Gokulam','1bhk','650','19','Any','6','NO'),
('113','7000','Hebbal','1bhk','650','20','Male','7','NO'),
('114','8000','JP nagar','2bhk','700','21','Female','7','NO'),
('115','8500','Bogadi','2bhk','750','22','Any','8','NO'),
('116','9000','Kuvempunagar','2bhk','850','18','Male','8','NO'),
('117','7000','Vijaynagar','1bhk','700','19','Female','9','NO'),
('118','10000','JP nagar','2bhk','1000','20','Any','9','NO'),
('119','12000','Gokulam','2bhk','1100','21','Male','10','NO'),
('120','11000','Vijaynagar','2bhk','950','22','Female','10','NO'),
('121','12000','VV Mohalla','2bhk','1200','18','Any','11','NO'),
('122','15000','Gokulam','3bhk','1500','19','Male','11','NO'),
('123','8500','Roopanagar','2bhk','850','20','Female','12','NO'),
('124','10000','Vijaynagar','2bhk','900','21','Any','12','NO'),
('125','7000','Hebbal','1bhk','750','22','Male','13','NO'),
('126','7500','Bogadi','1bhk','800','18','Female','13','NO'),
('127','8000','Kuvempunagar','2bhk','800','19','Any','14','NO'),
('128','9500','Hootgalli','2bhk','850','20','Male','14','NO'),
('129','10000','TK layout','2bhk','950','21','Female','15','NO'),
('130','11000','Hootgalli','2bhk','1000','22','Any','15','NO'),
('131','13000','Roopanagar','3bhk','1200','18','Male','16','NO'),
('132','8000','TK layout','2bhk','800','19','Female','16','NO'),
('133','9500','Hootgalli','2bhk','800','20','Any','17','NO'),
('134','9000','Hebbal','2bhk','700','21','Male','17','NO'),
('135','12000','Hebbal','2bhk','1000','22','Female','18','NO'),
('136','13000','Vijaynagar','2bhk','1200','18','Any','18','NO'),
('137','14000','Gokulam','2bhk','1400','19','Male','19','NO'),
('138','15000','Gokulam','3bhk','1500','20','Female','19','NO'),
('139','12000','Roopanagar','2bhk','1000','21','Any','20','NO'),
('140','9000','Kuvempunagar','1bhk','850','22','Male','20','NO'),
('141','11000','Bogadi','2bhk','1000','18','Female','21','NO'),
('142','12000','VV Mohalla','2bhk','900','19','Any','22','NO'),
('143','14000','Vijaynagar','2bhk','1300','20','Male','23','NO'),
('144','15000','Gokulam','2bhk','1500','21','Female','24','NO'),
('145','17000','Hebbal','3bhk','1500','22','Any','25','NO'),
('146','10000','TK layout','2bhk','800','18','Male','26','NO'),
('147','18000','Roopanagar','3bhk','1700','19','Female','27','NO'),
('148','17000','Hootgalli','2bhk','1500','20','Any','28','NO'),
('149','14000','Hootgalli','2bhk','1400','21','Male','29','NO'),
('150','16000','Bannimantap','2bhk','1500','22','Female','30','NO');





-- --------------------------------------------------------
CREATE TABLE `admin` (
  `admin_id` int(10) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


INSERT INTO `admin` (`admin_id`, `email`, `password`) VALUES
(1, 'aashi1112as@gmail.com', '12345');

-- --------------------------------------------------------

CREATE TABLE `owner` (
  `owner_id` int(10) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `age` int(10) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `phone_no` bigint(10) NOT NULL,
  `address` varchar(200) NOT NULL,
  `password` nvarchar(100) NOT NULL,
  `email` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `owner`
--
INSERT INTO `owner` (`owner_id`, `full_name`,`age`,`gender`,`phone_no`, `address`,`password`,`email`) VALUES
('1','Preethi','34','Female','8832911019','Kuvempunagar','ow001','preethi@gmail.com'),
('2','Anil','42','Male','8221074295','Vani Vilas Mohalla','ow002','anil@gmail.com'),
('3','Arun','46','Male','8326529810','Bannimantap','ow003','arun@gmail.com'),
('4','Roopa','48','Female','7483902541','Kalidasa Road','ow004','roopa@gmail.com'),
('5','Joseph','41','Male','7729102184','Gokulam','ow005','joseph@gmail.com'),
('6','Prakash','48','Male','7638278201','Manasagangothri','ow006','prakash@gmail.com'),
('7','Jyothi','44','Female','6447320478','Kuvempunagar','ow007','jyothi@gmail.com'),
('8','Kavya','40','Female','8743929281','Vani Vilas Mohalla','ow008','kavya@gmail.com'),
('9','Anjali','33','Female','9922964811','Bannimantap','ow009','anjali@gmail.com'),
('10','Manju','43','Male','9327238765','Kalidasa Road','ow010','manju@gmail.com'),
('11','Rahul','37','Male','8736243108','Gokulam','ow011','rahul@gmail.com'),
('12','Amit','30','Male','6782037629','Manasagangothri','ow012','amit@gmail.com'),
('13','Anshuman','35','Male','7473792013','Kuvempunagar','ow013','anshuman@gmail.com'),
('14','Jaya','28','Female','6782908377','Vani Vilas Mohalla','ow014','jaya@gmail.com'),
('15','Rekha','29','Female','6232930273','Bannimantap','ow015','rekha@gmail.com'),
('16','Smita','39','Female','6018474398','Kalidasa Road','ow016','smita@gmail.com'),
('17','Anant','36','Male','8197408375','Gokulam','ow017','anant@gmail.com'),
('18','Vanditha','32','Female','6818279384','Manasagangothri','ow018','vanditha@gmail.com'),
('19','Sujatha','41','Female','8542977344','Kuvempunagar','ow019','sujatha@gmail.com'),
('20','Ravi','54','Male','8642787722','Vani Vilas Mohalla','ow020','ravi@gmail.com'),
('21','Vidya','33','Female','6219368432','Bannimantap','ow021','vidya@gmail.com'),
('22','Harish','34','Male','6134565482','Kalidasa Road','ow022','harish@gmail.com'),
('23','Krishna','38','Male','6511386524','Gokulam','ow023','krishna@gmail.com'),
('24','Satish','44','Male','8248749322','Manasagangothri','ow024','satish@gmail.com'),
('25','Vishnu','30','Male','7372920183','Kuvempunagar','ow025','vishnu@gmail.com'),
('26','Keerthi','48','Female','7103748402','Vani Vilas Mohalla','ow026','keerthi@gmail.com'),
('27','Bharath','41','Male','7838603985','Bannimantap','ow027','bharath@gmail.com'),
('28','Manu','52','Male','6032748201','Kalidasa Road','ow028','manu@gmail.com'),
('29','Hema','56','Female','8920948742','Gokulam','ow029','hema@gmail.com'),
('30','Sapna','39','Female','6296987925','Manasagangothri','ow030','sapna@gmail.com');

UPDATE owner
SET password = MD5(password)
 WHERE owner_id IN (1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30);

-- --------------------------------------------------------
CREATE TABLE `property_photo` (
  `property_photo_id` int(12) NOT NULL,
  `p_photo` varchar(500) NOT NULL,
  `property_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `property_photo` (`property_photo_id`, `p_photo`, `property_id`) VALUES
(174, 'product-photo/aa.jpg', 101),
(175, 'product-photo/b.jpg', 102),
(176, 'product-photo/c.jpg', 103),
(177, 'product-photo/d.jpeg', 104),
(178, 'product-photo/e.jpg', 105),
(179, 'product-photo/f.jpg', 106),
(180, 'product-photo/g.jpg', 107),
(181, 'product-photo/h.jpg', 108),
(182, 'product-photo/i.jpeg', 109),
(183, 'product-photo/j.jpg', 110),
(184, 'product-photo/k.jpg', 111),
(185, 'product-photo/l.jpg', 112),
(186, 'product-photo/m.jpg', 113),
(187, 'product-photo/n.jpg', 114),
(188, 'product-photo/o.jpg', 115),
(189, 'product-photo/p.jpeg', 116),
(190, 'product-photo/q.jpeg', 117),
(191, 'product-photo/r.jpg', 118),
(192, 'product-photo/s.jpg', 119),
(193, 'product-photo/t.jpg', 120),
(194, 'product-photo/u.jpg', 121),
(195, 'product-photo/v.jpg', 122),
(196, 'product-photo/w.jpg', 123),
(197, 'product-photo/x.jpeg', 124),
(198, 'product-photo/y.jpeg', 125),
(199, 'product-photo/z.jpg', 126),
(200, 'product-photo/ab.jpg', 127),
(201, 'product-photo/ac.jpg', 128),
(202, 'product-photo/ad.jpeg', 129),
(203, 'product-photo/ae.jpg', 130),
(204, 'product-photo/af.jpeg', 131),
(205, 'product-photo/ag.jpeg', 132),
(206, 'product-photo/ah.jpg', 133),
(207, 'product-photo/ai.jpeg', 134),
(208, 'product-photo/aj.jpeg', 135),
(209, 'product-photo/ak.jpeg', 136),
(210, 'product-photo/al.jpg', 137),
(211, 'product-photo/am.jpg', 138),
(212, 'product-photo/an.jpeg', 139),
(213, 'product-photo/ao.jpeg', 140),
(214, 'product-photo/ap.jpeg', 141),
(215, 'product-photo/aq.jpg', 142),
(216, 'product-photo/ar.jpg', 143),
(217, 'product-photo/as.jpg', 144),
(218, 'product-photo/at.jpeg', 145),
(219, 'product-photo/au.jpg', 146),
(220, 'product-photo/av.jpg', 147),
(221, 'product-photo/ab.jpg', 148),
(222, 'product-photo/ac.jpg', 149),
(223, 'product-photo/ad.jpeg', 150);

-- --------------------------------------------------------
CREATE TABLE `tenant` (
  `tenant_id` int(10) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone_no` bigint(10) NOT NULL,
  `age` int(20) NOT NULL,
  `password` nvarchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `tenant` (`tenant_id`, `full_name`,`gender`, `email`,`phone_no`, `age`,`password`) VALUES
('201','Sahana','Female','sahana@gmail.com','6784920833','21','user001'),
('202','Harsha','Male','harsha@gmail.com','7892690080','20','user002'),
('203','Pratik','Male','pratik@gmail.com','7834024123','19','user003'),
('204','Geeta','Female','geeta@gmail.com','2382382288','21','user004'),
('205','Preeti','Female','preeti@gmail.com','9900394294','22','user005'),
('206','Keerthana','Female','keerthana@gmail.com','3857027123','21','user006'),
('207','Mythri','Female','mythri@gmail.com','7832782291','22','user007'),
('208','Diya','Female','diya@gmail.com','9888980675','23','user008'),
('209','Advaith','Male','advaith@gmail.com','7986785560','22','user009'),
('210','Indrajit','Male','indrajit@gmail.com','7802933231','21','user010'),
('211','Srujan','Male','srujan@gmail.com','8986754991','24','user011'),
('212','Anusha','Female','anusha22@gmail.com','6779870791','23','user012'),
('213','Vindhya','Female','vindhya@gmail.com','8890779072','22','user013'),
('214','Sushma','Female','sushma@gmail.com','9786702317','21','user014'),
('215','Amrutha','Female','amrutha12@gmail.com','6677987321','22','user015'),
('216','Surabhi','Female','surabi44@gmail.com','7676899022','21','user016'),
('217','Sanchith','Male','sanchith@gmail.com','8800329399','22','user017'),
('218','Sarthak','Male','sarthak@gmail.com','9791278332','21','user018'),
('219','Satwik','Male','satwik@gmail.com','8921013387','22','user019'),
('220','Goutham','Male','goutham@gmail.com','9683202011','21','user020'),
('221','Puneeth','Male','puneeth@gmail.com','997708345','24','user021'),
('222','Shreyas','Male','shreyas@gmail.com','7673452213','24','user022'),
('223','Vineeth','Male','vineeth@gmail.com','6633820912','25','user023'),
('224','Abhiram','Male','abhiram@gmail.com','8833202745','23','user024'),
('225','Raksha','Female','raksha@gmail.com','9932010022','25','user025'),
('226','Abhishek','Male','abhishek@gmail.com','8833920129','21','user026'),
('227','Vivek','Male','vivek123@gmail.com','7733820273','22','user027'),
('228','Tejas','Male','tejas@gmail.com','9020203774','23','user028'),
('229','Saniya','Female','saniya@gmail.com','8989302848','22','user029'),
('230','Akhila','Female','akhila@gmail.com','9900225539','21','user030'),
('231','Anvitha','Female','anvitha02@gmail.com','6393306041','20','user031'),
('232','Dhanush','Male','dhanush@gmail.com','7892020182','20','user032'),
('233','Deeksha','Female','deeksha@gmail.com','9902264821','20','user033'),
('234','Aditi','Female','aditi@gmail.com','7832207730','22','user034'),
('235','Akash','Male','akash@gmail.com','9328820193','21','user035'),
('236','Charan','Male','charan@gmail.com','8844920922','20','user036'),
('237','Pavan','Male','pavan@gmail.com','6843920939','19','user037'),
('238','Aman','Male','aman@gmail.com','9883023022','22','user038'),
('239','Raj','Male','raj@gmail.com','9369273876','20','user039'),
('240','Gagan','Male','gagan@gmail.com','7782018822','21','user040'),
('241','Vikram','Male','vikram@gmail.com','9753889920','22','user041'),
('242','Kunal','Male','kunal@gmail.com','8082892246','23','user042'),
('243','Ayush','Male','ayush@gmail.com','7088557721','24','user043'),
('244','Srushti','Female','srushti@gmail.com','9403114670','20','user044'),
('245','Priya','Female','priya@gmail.com','9970173483','21','user045'),
('246','Prajwal','Male','prajwal@gmail.com','8799564311','21','user046'),
('247','Bhoomika','Female','bhoomika@gmail.com','6772012345','22','user047'),
('248','Kriti','Female','kriti@gmail.com','7896009410','23','user048'),
('249','Suhas','Male','suhas@gmail.com','9847420024','21','user049'),
('250','Yashas','Male','yashas@gmail.com','6601942892','24','user050');

UPDATE tenant
SET password = md5(password)
WHERE tenant_id IN (201,202,203,204,205,206,207,208,209,210,211,212,213,214,215,216,217,218,219,220,221,222,223,224,225,226,227,228,229,230,231,232,233,234,235,236,
  237,238,239,240,241,242,243,244,245,246,247,248,249,250);

CREATE TABLE `booking` (
`property_id` int(10) NOT NULL,
`tenant_id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Indexes for dumped tables
--

--
-- Indexes for table `add_property`
--
ALTER TABLE `add_property`
  ADD PRIMARY KEY (`property_id`),
  ADD KEY `owner_id` (`owner_id`);

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `owner`
--
ALTER TABLE `owner`
  ADD PRIMARY KEY (`owner_id`);

--
-- Indexes for table `property_photo`
--
ALTER TABLE `property_photo`
  ADD PRIMARY KEY (`property_photo_id`),
  ADD KEY `property_id` (`property_id`);

--
-- Indexes for table `tenant`
--
ALTER TABLE `tenant`
  ADD PRIMARY KEY (`tenant_id`);

ALTER TABLE `booking`
  ADD PRIMARY KEY (`property_id`,`tenant_id`),
  ADD KEY `property_id` (`property_id`),
  ADD KEY `tenant_id` (`tenant_id`);
--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `add_property`
--
ALTER TABLE `add_property`
  MODIFY `property_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=125;

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `owner`
--
ALTER TABLE `owner`
  MODIFY `owner_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `property_photo`
--
ALTER TABLE `property_photo`
  MODIFY `property_photo_id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=178;

--
-- AUTO_INCREMENT for table `tenant`
--
ALTER TABLE `tenant`
  MODIFY `tenant_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `add_property`
--
ALTER TABLE `add_property`
  ADD CONSTRAINT `add_property_ibfk_1` FOREIGN KEY (`owner_id`) REFERENCES `owner` (`owner_id`) ON DELETE CASCADE;

--
-- Constraints for table `property_photo`
--
ALTER TABLE `property_photo`
  ADD CONSTRAINT `property_photo_ibfk_1` FOREIGN KEY (`property_id`) REFERENCES `add_property` (`property_id`) ON DELETE CASCADE ;

ALTER TABLE `booking`
  ADD CONSTRAINT `booking_ibfk_1` FOREIGN KEY (`property_id`) REFERENCES `add_property` (`property_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `booking_ibfk_2` FOREIGN KEY (`tenant_id`) REFERENCES `tenant` (`tenant_id`) ON DELETE CASCADE;


COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
