<?php
$property_id='';
$estimated_price='';
$location='';
$type='';
$area='';
$description_age='';
$description_gender='';
$owner_id='';
$booked='';
$p_photo='';

$db = new mysqli('localhost','root','','renthouse');

if($db->connect_error){
	echo "Error connecting database";
}

if(isset($_POST['add_property'])){
	add_property();
}

if(isset($_POST['owner_update'])){
	owner_update();
}


function add_property(){

	global $property_id,$estimated_price,$location,$type,$area,$description_age,$description_gender,$owner_id,$booked,$db;


	$estimated_price=validate($_POST['estimated_price']);
	$location=validate($_POST['location']);
	$type=validate($_POST['type']);
	$area=validate($_POST['area']);
	$description_age=validate($_POST['description_age']);
	$description_gender=validate($_POST['description_gender']);
	$booked='NO';

   	$u_email=$_SESSION['email'];
        $sql1="SELECT * from owner where email='$u_email'";
        $result1=mysqli_query($db,$sql1);

        if(mysqli_num_rows($result1)>0)
      {
          while($rowss=mysqli_fetch_assoc($result1)){
            $owner_id=$rowss['owner_id'];
   	$sql = "INSERT INTO add_property(estimated_price,location,type,area,description_age,description_gender,owner_id,booked) VALUES('$estimated_price','$location','$type','$area','$description_age','$description_gender','$owner_id','$booked')";
		$query=mysqli_query($db,$sql);

		$property_id = mysqli_insert_id($db);


  $p_photo="product-photo/nbkbkj.jpg";
	$sql2 = "INSERT INTO property_photo (p_photo,property_id) VALUES ('$p_photo','$property_id')";

  // Execute query
  mysqli_query($db, $sql2);

		if(!empty($query)){

?>

<style>
.alert {
  padding: 20px;
  background-color: #DC143C;
  color: white;
}

.closebtn {
  margin-left: 15px;
  color: white;
  font-weight: bold;
  float: right;
  font-size: 22px;
  line-height: 20px;
  cursor: pointer;
  transition: 0.3s;
}

.closebtn:hover {
  color: black;
}
</style>
<script>
	window.setTimeout(function() {
    $(".alert").fadeTo(1000, 0).slideUp(500, function(){
        $(this).remove();
    });
}, 2000);
</script>
<div class="container">
<div class="alert" role='alert'>
  <span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span>
  <center><strong>Your Product has been uploaded.</strong></center>
</div></div>


<?php
		}
		else{
			echo "error";
		}

}
}}

function owner_update(){
	global $owner_id,$full_name,$age,$gender,$phone_no,$address,$password,$email,$errors,$db;
	$owner_id=validate($_POST['owner_id']);
	$full_name=validate($_POST['full_name']);
	$age=validate($_POST['age']);
	$gender=validate($_POST['gender']);
	$phone_no=validate($_POST['phone_no']);
	$address=validate($_POST['address']);
	$email=validate($_POST['email']);
	$password = md5($password); // Encrypt password
		$sql = "UPDATE owner SET full_name='$full_name',age='$age',gender='$gender',phone_no='$phone_no',address='$address',email='$email' WHERE owner_id='$owner_id'";
		$query=mysqli_query($db,$sql);
		if(!empty($query)){
			?>

<style>
.alert {
  padding: 20px;
  background-color: #DC143C;
  color: white;
}

.closebtn {
  margin-left: 15px;
  color: white;
  font-weight: bold;
  float: right;
  font-size: 22px;
  line-height: 20px;
  cursor: pointer;
  transition: 0.3s;
}

.closebtn:hover {
  color: black;
}
</style>
<script>
	window.setTimeout(function() {
    $(".alert").fadeTo(1000, 0).slideUp(500, function(){
        $(this).remove();
    });
}, 2000);
</script>
<div class="container">
<div class="alert" role='alert'>
  <span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span>
  <center><strong>Your Information has been updated.</strong></center>
</div></div>


<?php
	}
}


function validate($data){
	$data = trim($data);
	$data = stripcslashes($data);
	$data = htmlspecialchars($data);
	return $data;
}




 ?>
